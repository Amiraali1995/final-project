import { checkForName } from "../src/client/js/nameChecker"


describe("Testing the submit functionality", () => {
    test("Testing the checkForName() function", () => {
         
           expect(checkForName).toBeDefined();
})});