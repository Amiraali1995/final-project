import { checkForURL } from "../src/client/js/urlChecker"

describe("Testing the submit functionality", () => {
    test("Testing the checkForURL() function", () => {
           expect(checkForURL).toBeDefined();
})});