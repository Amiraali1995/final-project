function checkForName(input_Text)
 {
    console.log(": Running checkForName :", input_Text);
    let names = [
        "Amira",
        "Ali",
        "Al-Naamani", ]
    if(names.includes(input_Text)) {
        alert("Welcome!!!!")
    }}
export { checkForName }
